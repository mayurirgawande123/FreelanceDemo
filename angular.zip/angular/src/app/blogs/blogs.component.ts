import { Component, OnInit } from '@angular/core';
import { BlogPostService } from '../services/blog-post.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.scss']
})
export class BlogsComponent implements OnInit {

  title = 'blog-post';
  blogs: any[] = [];
  name: string = '';
  content: string = '';
  isMyBlogs: boolean = false;
  constructor(private blogService: BlogPostService, private router: Router) {

  }

  ngOnInit(): void {
    this.blogService.get().subscribe(data => {
      this.blogs = data;
    })
  }

  showComments(blog: any) {
    this.blogService.getComments(blog.Id).subscribe(data => {
      blog.comments = data;
    })
  }

  myBlogs() {
    this.isMyBlogs = true;
    this.router.navigate(['/myBlogs'])
  }
  createBlogs() {
    this.isMyBlogs = true;
    this.router.navigate(['/createBlogs']);
  }

  add(blog: any) {
    this.blogService.createComment({ name: this.name, content: this.content, blogId: blog.Id }).subscribe(data => {
      alert('Comment Added Successfully');
      this.blogService.getComments(blog.Id).subscribe(data => {
        blog.comments = data;
      })
    })
  }

}
