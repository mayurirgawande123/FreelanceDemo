import { Component, OnInit } from '@angular/core';
import { BlogPostService } from '../services/blog-post.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-blog',
  templateUrl: './edit-blog.component.html',
  styleUrls: ['./edit-blog.component.scss']
})
export class EditBlogComponent implements OnInit {

  public title: any = localStorage.getItem('title');
  public content: any = localStorage.getItem('content');
  public id: any = localStorage.getItem('id');

  constructor(private blogService: BlogPostService, private router: Router) { }

  ngOnInit(): void {
  }

  edit() {
    this.blogService.updateBlog(this.id, { title: this.title, content: this.content }).subscribe(data => {
      alert('Blog updated Successfully');
      this.router.navigate(['/myBlogs'])
    });
  }


}
