import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BlogPostService {

  constructor(private http: HttpClient) { }

  public get(): Observable<any> {
    return this.http.get('http://localhost:8080/api/tutorials');
  }

  public getMyBlogs(): Observable<any> {
    return this.http.get('http://localhost:8080/api/tutorials/myBlogs');
  }

  public getComments(id: any): Observable<any> {
    return this.http.get('http://localhost:8080/api/tutorials/getAllComments/' + id);
  }

  public createBlogs(data: any): Observable<any> {
    return this.http.post('http://localhost:8080/api/tutorials/createPost/', data);
  }

  public createComment(data: any): Observable<any> {
    return this.http.post('http://localhost:8080/api/tutorials/createComment/', data);
  }

  public updateBlog(id: any, data: any): Observable<any> {
    return this.http.put('http://localhost:8080/api/tutorials/' + id, data);
  }

  public deleteBlog(id: any): Observable<any> {
    return this.http.delete('http://localhost:8080/api/tutorials/' + id);
  }
}
