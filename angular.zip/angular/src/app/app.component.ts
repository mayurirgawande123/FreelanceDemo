import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit  {
  title = 'blog-post';
  constructor(private router: Router  ) {

  }

  ngOnInit(): void {
    this.router.navigate(['/posts']);
  }

  myBlogs(){
    this.router.navigate(['/myBlogs'])
  }
  createBlogs(){
    this.router.navigate(['/createBlogs']);
  }
}
