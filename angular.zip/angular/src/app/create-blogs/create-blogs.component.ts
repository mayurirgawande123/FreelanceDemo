import { Component, OnInit } from '@angular/core';
import { BlogPostService } from '../services/blog-post.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-blogs',
  templateUrl: './create-blogs.component.html',
  styleUrls: ['./create-blogs.component.scss']
})
export class CreateBlogsComponent implements OnInit {

  public title: string = '';
  public content: string = '';

  constructor(private blogService: BlogPostService, private router: Router) { }

  ngOnInit(): void {
  }

  post() {
    this.blogService.createBlogs({ title: this.title, content: this.content }).subscribe(data => {
      alert('Blog Postd Successfully');
      this.router.navigate(['/myBlogs'])
    });
  }

}
