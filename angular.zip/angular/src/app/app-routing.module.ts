import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MyBlogsComponent } from './my-blogs/my-blogs.component';
import { CreateBlogsComponent } from './create-blogs/create-blogs.component';
import { BlogsComponent } from './blogs/blogs.component';
import { EditBlogComponent } from './edit-blog/edit-blog.component';

const routes: Routes = [
  { path: 'myBlogs', component: MyBlogsComponent },
  { path: 'createBlogs', component: CreateBlogsComponent },
  { path: 'posts', component: BlogsComponent },
  { path: 'editBlog', component: EditBlogComponent },
  { path: '',   redirectTo: '/', pathMatch: 'full' }, // redirect to `first-component`
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
