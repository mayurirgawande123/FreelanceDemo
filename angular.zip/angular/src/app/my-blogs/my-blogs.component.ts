import { Component, OnInit } from '@angular/core';
import { BlogPostService } from '../services/blog-post.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-my-blogs',
  templateUrl: './my-blogs.component.html',
  styleUrls: ['./my-blogs.component.scss']
})
export class MyBlogsComponent implements OnInit {

  title = 'blog-post';
  blogs: any[] = [];
  constructor(private blogService: BlogPostService, private router:Router) {

  }

  ngOnInit(): void {
    this.blogService.getMyBlogs().subscribe(data => {
      this.blogs = data;
    })
  }

  edit(blog: any) {
    localStorage.setItem("title",blog.Title);
    localStorage.setItem("content",blog.Content);
    localStorage.setItem("id",blog.Id)
    this.router.navigate(['/editBlog']);
  }

  delete(id: any) {
    this.blogService.deleteBlog(id).subscribe(data => {
      alert('Blog deleted Successfully');
      this.blogService.getMyBlogs().subscribe(data => {
        this.blogs = data;
      })
    });
  }

  // showComments(blog: any) {
  //   this.blogService.getComments(blog.Id).subscribe(data => {
  //     blog.comments=data;
  //   })
  // }

}
