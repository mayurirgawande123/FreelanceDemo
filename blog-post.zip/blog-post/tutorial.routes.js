module.exports = app => {
    const tutorials = require("./controller/tutorial.controller.js");
  
    var router = require("express").Router();
  
    // Create a new Tutorial
    router.post("/createPost", tutorials.create);
  

    router.post("/createComment", tutorials.createComment);
    // Retrieve all Tutorials
    router.get("/", tutorials.findAll);
    router.get("/myBlogs", tutorials.findAllMyBlogs);

    router.get("/getAllComments/:id", tutorials.findAllComments);
  
    app.use('/api/tutorials', router);
      // Update a Tutorial with id
    router.put("/:id", tutorials.update);

    // Delete a Tutorial with id
    router.delete("/:id", tutorials.delete);
  };