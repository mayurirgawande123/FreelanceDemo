

module.exports= {
  host: "sql9.freesqldatabase.com",
  user: "sql9621063",
  password: "BYJPXuQMAE",
//   port:"4497",
   database:"sql9621063"
};


